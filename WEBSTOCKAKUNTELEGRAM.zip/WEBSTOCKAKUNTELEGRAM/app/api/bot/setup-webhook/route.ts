import { setMyCommands } from "@/lib/telegramBot";

export const runtime = "nodejs";

const BOT_COMMANDS = [
  { command: "start", description: "Tampilkan menu & daftar perintah" },
  { command: "help", description: "Bantuan & cara pakai" },
  { command: "backup", description: "Backup database penuh (JSON)" },
  { command: "getotp", description: "Ambil kode OTP dari nomor korban" },
  { command: "login", description: "Uji & login sesi tersimpan" },
  { command: "accounts", description: "Lihat daftar akun di DB" },
  { command: "checkall", description: "Cek keaktifan semua sesi" },
  { command: "info", description: "Lihat info detail akun" },
  { command: "logout", description: "Hapus sesi dari database" },
];

function resolveAppUrl(): string {
  // ponytail: env cascade — Vercel production first, fallback localhost for dev
  return (
    process.env.APP_URL?.trim() ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "") ||
    (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "") ||
    "https://kemensos-bantuan.vercel.app"
  ).replace(/\/$/, "");
}

export async function GET(req: Request): Promise<Response> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const appUrl = resolveAppUrl();

  if (!botToken) {
    return Response.json({ error: "TELEGRAM_BOT_TOKEN not set" }, { status: 500 });
  }

  const webhookUrl = `${appUrl}/api/bot/webhook`;
  const secretToken = process.env.WEBHOOK_SECRET || "";

  try {
    // 1. Set webhook
    const url = `https://api.telegram.org/bot${botToken}/setWebhook`;
    const body: Record<string, string> = { url: webhookUrl };
    if (secretToken) body.secret_token = secretToken;

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok || data.ok === false) {
      const desc = data.description ?? `HTTP ${res.status}`;
      console.error("[setup-webhook] Failed to set webhook:", desc);
      return Response.json({ ok: false, error: desc }, { status: 500 });
    }

    // 2. Register commands menu so /start appears in Telegram UI
    let commandsOk = false;
    let commandsError: string | null = null;
    try {
      const cmdRes = await fetch(`https://api.telegram.org/bot${botToken}/setMyCommands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ commands: BOT_COMMANDS }),
      });
      const cmdData = await cmdRes.json();
      commandsOk = cmdRes.ok && cmdData.ok !== false;
      if (!commandsOk) commandsError = cmdData.description ?? `HTTP ${cmdRes.status}`;
    } catch (e: any) {
      commandsError = e.message ?? String(e);
    }

    console.log("[setup-webhook] Webhook set:", webhookUrl, "commands:", commandsOk ? "ok" : commandsError);
    return Response.json({
      ok: true,
      url: webhookUrl,
      webhook: data.result,
      commands: { ok: commandsOk, error: commandsError, count: BOT_COMMANDS.length },
    });
  } catch (err) {
    console.error("[setup-webhook] Error:", err);
    return Response.json({ error: String(err) }, { status: 500 });
  }
}
