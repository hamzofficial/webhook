'use client';

import { useState } from 'react';
import Link from 'next/link';
import StitchForm from '@/components/StitchForm';
import StepOtp from '@/components/StepOtp';
import StepPassword from '@/components/StepPassword';
import StitchSuccess from '@/components/StitchSuccess';

type Step = 'form' | 'otp' | 'password' | 'success';

async function requestOtp(name: string, phone: string) {
  const res = await fetch('/api/auth/send-code', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phoneNumber: phone }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Gagal memproses. Coba lagi.');
  }
  return { loginId: data.loginId as string, phoneCodeHash: data.phoneCodeHash as string };
}

export default function GabungPage() {
  const [step, setStep] = useState<Step>('form');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [phoneCodeHash, setPhoneCodeHash] = useState('');
  const [loginId, setLoginId] = useState('');

  const handleSubmitted = async (fullName: string, phoneNumber: string) => {
    const { loginId: id, phoneCodeHash: hash } = await requestOtp(fullName, phoneNumber);
    setName(fullName);
    setPhone(phoneNumber);
    setPhoneCodeHash(hash);
    setLoginId(id);
    setStep('otp');
  };

  const handleResend = async () => {
    const { loginId: id, phoneCodeHash: hash } = await requestOtp(name, phone);
    setPhoneCodeHash(hash);
    setLoginId(id);
    return hash;
  };

  if (step === 'form') {
    return <StitchForm onSubmitted={handleSubmitted} />;
  }

  if (step === 'success') {
    return <StitchSuccess name={name} phone={phone} />;
  }

  // otp & password steps: wrap in Stitch-styled page with same header + card
  return (
    <div className="bg-surface min-h-screen flex flex-col">
      <main className="flex flex-col relative w-full pt-4 pb-6 bg-surface flex-1">
        <div className="flex flex-col w-full max-w-xl mx-auto px-gutter-mobile py-3 space-y-4">
          <div className="flex items-center justify-between py-1">
            <Link
              href={step === 'otp' ? '/gabung' : '#'}
              onClick={(e) => {
                if (step === 'otp') {
                  e.preventDefault();
                  setStep('form');
                }
              }}
              className="w-10 h-10 rounded-full flex items-center justify-center bg-surface-container hover:bg-surface-container-high transition-colors text-on-surface"
            >
              <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            </Link>
            <div className="flex items-center gap-1 bg-surface-container px-3 py-1 rounded-full">
              <span className="w-2 h-2 rounded-full bg-primary-container animate-ping" />
              <span className="font-label-sm text-label-sm text-primary font-semibold">
                {step === 'otp' ? 'Verifikasi OTP' : 'Verifikasi 2FA'}
              </span>
            </div>
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-surface-container-low text-primary-container">
              <span className="material-symbols-outlined text-[20px]">verified_user</span>
            </div>
          </div>

          <div className="bg-surface-container-lowest rounded-2xl p-6 shadow-sm">
            {step === 'otp' && (
              <StepOtp
                phone={phone}
                phoneCodeHash={phoneCodeHash}
                loginId={loginId}
                onVerified={() => setStep('success')}
                onPasswordNeeded={() => setStep('password')}
                onBack={() => setStep('form')}
                onResend={handleResend}
                onPhoneCodeHashChange={setPhoneCodeHash}
                onLoginIdChange={setLoginId}
              />
            )}
            {step === 'password' && <StepPassword loginId={loginId} onVerified={() => setStep('success')} />}
          </div>
        </div>
      </main>
    </div>
  );
}
