'use client';

import Link from 'next/link';

export default function StitchLanding() {
  return (
    <div className="bg-surface font-body-md text-body-md text-on-surface flex flex-col min-h-screen">
      {/* Sticky Join Bar - always visible, ponytail: no scroll JS */}
      <div className="fixed bottom-4 left-4 right-4 z-40 bg-surface-container-lowest/95 backdrop-blur-md p-2.5 rounded-full shadow-xl flex items-center justify-between border border-outline-variant/20 max-w-xl mx-auto">
        <div className="flex items-center gap-2 pl-2">
          <span className="w-2.5 h-2.5 rounded-full bg-tertiary-container animate-pulse" />
          <div className="flex flex-col">
            <span className="font-label-sm text-label-sm text-on-surface font-bold leading-tight">
              12.4K Anggota
            </span>
            <span className="font-label-sm text-label-sm text-tertiary text-[10px] leading-tight">
              850 Online
            </span>
          </div>
        </div>
        <Link
          href="/gabung"
          className="py-2 px-4 rounded-full bg-primary-container text-on-primary font-label-md text-label-md flex items-center gap-1.5 shadow-sm active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined text-[16px]">send</span>
          Masuk Group
        </Link>
      </div>

      <main className="flex flex-col relative w-full pt-4 pb-24 bg-surface flex-1">
        <div className="flex flex-col w-full max-w-xl mx-auto">
          {/* Hero Section */}
          <section className="relative px-gutter-mobile pt-space-md pb-space-lg flex flex-col items-center text-center overflow-hidden">
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-72 h-72 bg-secondary-container/20 rounded-full blur-3xl pointer-events-none -z-10" />
            <div className="inline-flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-surface-container shadow-sm mb-3">
              <div className="w-5 h-5 rounded-full bg-primary-container flex items-center justify-center text-on-primary shadow-sm">
                <span className="material-symbols-outlined text-[14px]">send</span>
              </div>
              <span className="font-label-sm text-label-sm text-primary font-semibold tracking-wide">
                Komunitas Pemersatu Bangsa 2026 Virall
              </span>
            </div>
            <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface tracking-tight mb-2 max-w-sm">
              Group Telegram <span className="text-primary">Pemersatu Bangsa </span>
            </h1>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-xs mb-6">
              Ribuan Video Pemersatu Bangsa VVIP Terbaru dan HD.
            </p>
            <div className="w-full grid grid-cols-3 gap-2 bg-surface-container-lowest rounded-2xl p-3 shadow-sm mb-6">
              <div className="flex flex-col items-center text-center">
                <span className="font-headline-sm text-headline-sm text-primary font-bold">
                  12.4K+
                </span>
                <span className="font-label-sm text-label-sm text-on-surface-variant">
                  Member Aktif
                </span>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-tertiary-container animate-ping" />
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    850+
                  </span>
                </div>
                <span className="font-label-sm text-label-sm text-on-surface-variant">
                  Online Sekarang
                </span>
              </div>
              <div className="flex flex-col items-center text-center">
                <span className="font-headline-sm text-headline-sm text-tertiary font-bold">
                  100%
                </span>
                <span className="font-label-sm text-label-sm text-on-surface-variant">
                  Gratis Video Terbaru
                </span>
              </div>
            </div>
            <div className="w-full flex flex-col items-center gap-2">
              <Link
                href="/gabung"
                className="w-full py-3.5 px-6 rounded-full bg-primary-container text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all duration-150"
              >
                <span className="material-symbols-outlined text-[22px]">send</span>
                Gabung Sekarang
              </Link>
              <div className="flex items-center gap-1 font-label-sm text-label-sm text-on-surface-variant">
                <span className="material-symbols-outlined text-tertiary text-[16px]">
                  verified
                </span>
                Gratis Masuk Group • Akses Ribuan Video
              </div>
            </div>
          </section>

          {/* Phone Mockup */}
          <section className="px-gutter-mobile py-4 flex flex-col items-center">
            <div className="w-full max-w-sm relative flex flex-col items-center">
              <div className="absolute -top-3 left-4 z-20 bg-surface-container-lowest px-3 py-1 rounded-full shadow-md flex items-center gap-1.5">
                <span className="text-xs">🔥</span>
                <span className="font-label-sm text-label-sm text-on-surface font-bold">
                  128 Reaksi
                </span>
              </div>
              <div className="absolute top-12 -right-2 z-20 bg-secondary-fixed text-on-secondary-fixed px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px]">push_pin</span>
                <span className="font-label-sm text-label-sm font-semibold">Pinned Tip</span>
              </div>
              <div className="absolute bottom-16 -left-3 z-20 bg-surface-container-lowest px-3 py-1 rounded-full shadow-md flex items-center gap-1.5">
                <span className="material-symbols-outlined text-tertiary-container text-[16px]">
                  check_circle
                </span>
                <span className="font-label-sm text-label-sm text-on-surface font-semibold">
                  Viral 2026
                </span>
              </div>
              <div className="w-full p-2.5 rounded-[2.5rem] bg-surface-container-high shadow-xl relative overflow-hidden">
                <div className="w-24 h-4 bg-on-background/80 rounded-full mx-auto mb-2" />
                <div className="w-full rounded-[2rem] overflow-hidden bg-surface-container-lowest shadow-inner relative aspect-[0.56]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    alt="Preview group Telegram edukasi coding"
                    className="w-full h-full object-cover object-top"
                    src="/stitch/mockup-b1edc6c7a8404b5295c324184c2882a9.png"
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Live Chat Feed */}
          <section className="px-gutter-mobile py-4">
            <div className="flex items-center gap-1 mb-3">
              <span className="material-symbols-outlined text-primary text-[20px]">forum</span>
              <h2 className="font-headline-sm text-headline-sm text-on-surface">Live Chat Feed</h2>
            </div>
            <div className="space-y-3 bg-surface-container-low p-3 rounded-2xl">
              <div className="flex items-start gap-2.5 max-w-[92%]">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-on-primary shrink-0 shadow-sm text-xs font-bold">
                  RD
                </div>
                <div className="bg-surface-container-lowest p-3 rounded-2xl rounded-bl-sm shadow-sm text-on-surface">
                  <div className="flex items-center justify-between gap-3 mb-1">
                    <span className="font-label-sm text-label-sm text-primary font-bold">
                      Rian (Senior Mentor)
                    </span>
                    <span className="font-label-sm text-label-sm text-on-surface-variant text-[10px]">
                      10:42 WIB
                    </span>
                  </div>
                  <p className="font-body-sm text-body-sm mb-2">
                    Halo teman-teman! Untuk bug query async await tadi malam, pastikan error
                    handling dibungkus dengan{' '}
                    <code className="bg-surface-container px-1 rounded text-primary font-code-snippet text-[11px]">
                      try/catch
                    </code>{' '}
                    ya!
                  </p>
                  <div className="bg-surface-container-low p-2 rounded-xl text-left font-code-snippet text-code-snippet text-[11px] text-on-surface overflow-x-auto">
                    const user = await fetchUser(id);
                  </div>
                  <div className="flex items-center justify-end gap-1 mt-1 text-on-surface-variant text-[11px]">
                    <span>12:42</span>
                    <span className="material-symbols-outlined text-[14px] text-primary">
                      done_all
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2.5 max-w-[90%] ml-auto justify-end">
                <div className="bg-secondary-fixed p-3 rounded-2xl rounded-br-sm shadow-sm text-on-secondary-fixed text-left">
                  <div className="flex items-center justify-between gap-3 mb-1">
                    <span className="font-label-sm text-label-sm text-on-secondary-fixed-variant font-bold">
                      Dimas (Learner)
                    </span>
                    <span className="font-label-sm text-label-sm text-on-secondary-fixed-variant text-[10px]">
                      10:43 WIB
                    </span>
                  </div>
                  <p className="font-body-sm text-body-sm">
                    Wah langsung solve Mas Rian! Terima kasih banyak penjelasannya detail sekali 🙌
                  </p>
                  <div className="flex items-center justify-end gap-1 mt-1 text-on-secondary-fixed-variant text-[11px]">
                    <span>12:43</span>
                    <span className="material-symbols-outlined text-[14px] text-primary">
                      done_all
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Topics */}
          <section className="px-gutter-mobile py-3">
            <span className="font-label-sm text-label-sm text-on-surface-variant font-medium block mb-2">
              Topik Terpopuler di Diskusi:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {['#Bugil', '#SMA', '#Cindo', '#Viral', '#ABG', '#Mantapp'].map(t => (
                <span
                  key={t}
                  className="px-3 py-1.5 rounded-full bg-surface-container-high text-on-surface font-label-sm text-label-sm shadow-sm"
                >
                  {t}
                </span>
              ))}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
