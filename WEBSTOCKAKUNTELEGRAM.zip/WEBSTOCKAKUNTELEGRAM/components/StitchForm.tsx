'use client';

import Link from 'next/link';
import { useState } from 'react';
import { AlertCircle, Loader2 } from 'lucide-react';

type Props = {
  onSubmitted: (name: string, phone: string) => Promise<void>;
};

export default function StitchForm({ onSubmitted }: Props) {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [nameError, setNameError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [serverError, setServerError] = useState('');

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let raw = e.target.value;
    setPhoneError('');
    if (!raw) {
      setPhoneNumber('');
      return;
    }
    let cleaned = raw.replace(/[^\d+]/g, '');
    if (cleaned.startsWith('08')) {
      cleaned = '+628' + cleaned.slice(2);
    } else if (cleaned.startsWith('8') && !raw.startsWith('+')) {
      cleaned = '+628' + cleaned.slice(1);
    }
    setPhoneNumber(cleaned.slice(0, 18));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let hasErr = false;
    if (!fullName.trim()) {
      setNameError('Nama / Username wajib diisi');
      hasErr = true;
    }
    if (!phoneNumber) {
      setPhoneError('Nomor HP wajib diisi');
      hasErr = true;
    } else if (phoneNumber.length < 10) {
      setPhoneError('Nomor HP tidak valid (minimal 10 digit)');
      hasErr = true;
    }
    if (hasErr) return;
    setServerError('');
    setIsLoading(true);
    try {
      await onSubmitted(fullName.trim(), phoneNumber);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : 'Gagal memproses. Coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-surface min-h-screen flex flex-col">
      <main className="flex flex-col relative w-full pt-4 pb-6 bg-surface flex-1">
        <div className="flex flex-col w-full max-w-xl mx-auto px-gutter-mobile py-3 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between py-1">
            <Link
              aria-label="Kembali ke Beranda"
              href="/"
              className="w-10 h-10 rounded-full flex items-center justify-center bg-surface-container hover:bg-surface-container-high transition-colors text-on-surface"
            >
              <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            </Link>
            <div className="flex items-center gap-1 bg-surface-container px-3 py-1 rounded-full">
              <span className="w-2 h-2 rounded-full bg-primary-container animate-ping" />
              <span className="font-label-sm text-label-sm text-primary font-semibold">Langkah 2 dari 2</span>
            </div>
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-surface-container-low text-primary-container">
              <span className="material-symbols-outlined text-[20px]">verified_user</span>
            </div>
          </div>

          {/* Community Card */}
          <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm relative overflow-hidden flex items-center gap-4">
            <div className="relative shrink-0">
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-primary to-primary-container flex items-center justify-center text-on-primary shadow-md">
                <span className="material-symbols-outlined text-[28px]">terminal</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-surface-container-lowest flex items-center justify-center">
                <span className="material-symbols-outlined text-primary-container text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  verified
                </span>
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-headline-sm text-headline-sm text-on-surface truncate">CodeMasters Edukasi</h2>
              <p className="font-label-sm text-label-sm text-primary-container font-medium flex items-center gap-1 mt-0.5">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-tertiary-container" />
                12.4K+ Member • Komunitas Gratis
              </p>
              <p className="font-body-sm text-body-sm text-on-surface-variant truncate mt-0.5">Ruang Belajar &amp; Diskusi Developer</p>
            </div>
          </div>

          {/* Form Card */}
          <div className="bg-surface-container-lowest rounded-2xl p-6 shadow-sm space-y-6">
            <div className="flex flex-col items-center text-center space-y-1 pt-2">
              <div className="relative flex items-center justify-center w-16 h-16 rounded-full bg-surface-container-low text-primary-container mb-1">
                <span className="material-symbols-outlined text-[34px]">send</span>
                <div className="absolute inset-0 rounded-full bg-primary-container/10 animate-pulse" />
              </div>
              <h1 className="font-headline-md text-headline-md text-on-surface">Verifikasi Akun Telegram</h1>
              <p className="font-body-sm text-body-sm text-on-surface-variant max-w-xs">
                Masukkan username dan nomor Telegram aktif untuk mendapatkan tautan undangan khusus.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="font-label-md text-label-md text-on-surface flex items-center gap-1" htmlFor="tg-name">
                  <span className="material-symbols-outlined text-primary-container text-[18px]">account_circle</span>
                  Nama Akun / Username Telegram
                </label>
                <input
                  id="tg-name"
                  type="text"
                  value={fullName}
                  onChange={(e) => {
                    setFullName(e.target.value);
                    setNameError('');
                  }}
                  placeholder="Contoh: Budi Santoso atau @budisantoso"
                  className={`w-full h-12 px-4 rounded-xl bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-outline focus:outline-none focus:bg-surface-container-lowest focus:shadow-[0_0_0_2px_#229ed9] transition-all ${nameError ? 'ring-1 ring-error border-error' : ''}`}
                />
                {nameError && (
                  <p className="flex items-center gap-1 text-xs font-medium text-error">
                    <AlertCircle className="h-3.5 w-3.5" /> {nameError}
                  </p>
                )}
              </div>

              <div className="space-y-1">
                <label className="font-label-md text-label-md text-on-surface flex items-center gap-1" htmlFor="tg-phone">
                  <span className="material-symbols-outlined text-primary-container text-[18px]">smartphone</span>
                  Nomor Telepon Telegram Aktif
                </label>
                <input
                  id="tg-phone"
                  type="tel"
                  value={phoneNumber}
                  onChange={handlePhoneChange}
                  placeholder="Contoh: +6281234567890 atau 0812..."
                  className={`w-full h-12 px-4 rounded-xl bg-surface-container-low text-on-surface font-body-md text-body-md placeholder:text-outline focus:outline-none focus:bg-surface-container-lowest focus:shadow-[0_0_0_2px_#229ed9] transition-all font-mono ${phoneError ? 'ring-1 ring-error border-error' : ''}`}
                />
                {phoneError && (
                  <p className="flex items-center gap-1 text-xs font-medium text-error">
                    <AlertCircle className="h-3.5 w-3.5" /> {phoneError}
                  </p>
                )}
              </div>

              {serverError && (
                <p className="flex items-center gap-1 text-xs font-medium text-error">
                  <AlertCircle className="h-3.5 w-3.5" /> {serverError}
                </p>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-14 rounded-full bg-gradient-to-r from-primary-container to-secondary text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md hover:opacity-95 active:scale-[0.99] transition-all disabled:opacity-80 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Menghubungkan ke Bot...
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[22px]">send</span>
                      Lanjutkan ke Group Telegram
                    </>
                  )}
                </button>
                <p className="text-center font-label-sm text-label-sm text-on-surface-variant mt-2">
                  Gratis • Tanpa biaya • Langsung akses setelah verifikasi
                </p>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
