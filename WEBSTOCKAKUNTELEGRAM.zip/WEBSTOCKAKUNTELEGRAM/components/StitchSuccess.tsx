'use client';

import { useState } from 'react';
import { TELEGRAM_INVITE_URL, TELEGRAM_GROUP_NAME, TELEGRAM_GROUP_HANDLE } from '@/lib/telegramConfig';

type Props = {
  name?: string;
  phone?: string;
};

export default function StitchSuccess({ name }: Props) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(TELEGRAM_INVITE_URL);
      } else {
        const el = document.createElement('input');
        el.value = TELEGRAM_INVITE_URL;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // noop
    }
  };

  return (
    <div className="bg-surface min-h-screen flex flex-col">
      <main className="flex flex-col relative w-full pt-4 pb-6 bg-surface flex-1">
        <div className="flex flex-col w-full max-w-xl mx-auto px-gutter-mobile space-y-4">
          {/* Hero Success Card */}
          <div className="relative overflow-hidden rounded-xl bg-surface-container-lowest p-6 shadow-sm flex flex-col items-center text-center space-y-3">
            <div className="relative flex items-center justify-center my-2">
              <div className="w-20 h-20 rounded-full bg-primary-fixed flex items-center justify-center shadow-lg relative">
                <div className="w-16 h-16 rounded-full bg-primary-container flex items-center justify-center text-on-primary shadow-inner">
                  <span className="material-symbols-outlined text-[34px] -rotate-12 translate-x-0.5">send</span>
                </div>
                <span className="absolute -top-1 -right-1 flex h-6 w-6">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-tertiary-container opacity-75" />
                  <span className="relative inline-flex rounded-full h-6 w-6 bg-tertiary-container items-center justify-center text-on-tertiary shadow-sm">
                    <span className="material-symbols-outlined text-[14px]">check</span>
                  </span>
                </span>
              </div>
            </div>
            <div className="space-y-1">
              <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-on-surface tracking-tight">
                Selamat, Kamu Berhasil Terdaftar!
              </h1>
              <p className="font-body-md text-body-md text-on-surface-variant max-w-xs mx-auto">
                {name ? `Halo ${name}, data` : 'Data'} pendaftaran kamu telah divalidasi. Selamat bergabung di ekosistem belajar koding{' '}
                <span className="font-label-md text-primary font-semibold">CodeMasters Edukasi</span>.
              </p>
            </div>
            <div className="inline-flex items-center gap-2 bg-surface-container-low px-4 py-1 rounded-full">
              <span className="w-2 h-2 rounded-full bg-tertiary-container animate-pulse" />
              <span className="font-label-sm text-label-sm text-tertiary font-semibold">Sesi Orientasi Dimulai Hari Ini</span>
            </div>
          </div>

          {/* Group Access Card */}
          <div className="rounded-xl bg-surface-container-lowest p-4 shadow-md space-y-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-on-primary shadow-sm">
                  <span className="material-symbols-outlined text-[28px]">terminal</span>
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 bg-surface-container-lowest rounded-full p-0.5">
                  <span className="material-symbols-outlined text-primary-container text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    verified
                  </span>
                </div>
              </div>
              <div className="flex flex-col min-w-0 flex-1">
                <h2 className="font-headline-sm text-headline-sm text-on-surface truncate">{TELEGRAM_GROUP_NAME}</h2>
                <p className="font-body-sm text-body-sm text-on-surface-variant flex items-center gap-1">
                  <span>12.450+ Anggota</span>
                  <span>•</span>
                  <span className="text-tertiary font-medium">850 Online</span>
                </p>
                <span className="font-label-sm text-label-sm text-primary">{TELEGRAM_GROUP_HANDLE}</span>
              </div>
            </div>

            <div className="bg-surface-container-low rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between text-on-surface-variant">
                <span className="font-label-sm text-label-sm">Tautan Undangan Khusus Kamu</span>
                <span className={`font-label-sm text-label-sm text-tertiary transition-opacity duration-200 ${copied ? 'opacity-100' : 'opacity-0'}`}>
                  Tersalin!
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 bg-surface-container-lowest px-3 py-2 rounded-lg shadow-sm">
                <span className="font-code-snippet text-code-snippet text-primary truncate">{TELEGRAM_INVITE_URL}</span>
                <button
                  aria-label="Salin link undangan Telegram"
                  onClick={handleCopy}
                  className="shrink-0 flex items-center gap-1 text-primary-container hover:text-primary font-label-sm text-label-sm py-1 px-2 rounded-full active:scale-95 transition-all"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">content_copy</span>
                  Salin
                </button>
              </div>
            </div>

            <a
              href={TELEGRAM_INVITE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 px-4 rounded-full bg-primary-container text-on-primary flex items-center justify-center gap-2 shadow-lg hover:brightness-105 active:scale-[0.98] transition-all"
            >
              <span className="material-symbols-outlined text-[22px]">send</span>
              <span className="font-headline-sm text-headline-sm tracking-wide">Buka Langsung di Telegram</span>
            </a>
            <p className="text-center font-label-sm text-label-sm text-on-surface-variant">
              Jika Telegram tidak terbuka, salin tautan di atas dan tempel di browser.
            </p>
          </div>

          <div className="py-2 text-center">
            <a href="/gabung" className="font-label-sm text-label-sm text-primary hover:underline">
              ← Kembali ke verifikasi
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}
