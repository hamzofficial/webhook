import { test, expect } from '@playwright/test';

// Helper to fill React controlled input via native setter (needed for this app's custom phone logic)
async function fillReactInput(page, selector: string, value: string) {
  await page.evaluate(({ selector, value }) => {
    const el = document.querySelector(selector) as HTMLInputElement;
    if (!el) return;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')!.set!;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }, { selector, value });
  await page.waitForTimeout(200);
  // verify and retry if React hasn't updated
  const actual = await page.locator(selector).inputValue();
  if (actual !== value) {
    // phone auto-format case: 0812... should become +628..., accept that
    if (value.startsWith('081') && actual === '+628' + value.slice(2)) return;
    // otherwise retry once more
    await page.locator(selector).fill(value);
  }
}

test.describe('WEBSTOCKAKUNTELEGRAM — E2E dari awal sampai selesai (MCP visible)', () => {
  test.beforeEach(async ({ page }) => {
    // Mock Telegram API — ponytail: no real OTP, pure UI flow test
    await page.route('**/api/auth/send-code', async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, loginId: 'mock-login-12345', phoneCodeHash: 'mock-hash-abcde' }),
      });
    });
    await page.route('**/api/auth/verify-code', async route => {
      const body = route.request().postDataJSON() as { code: string } | null;
      const code = body?.code;
      if (code === '12345') {
        await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ success: true }) });
      } else if (code === '00000') {
        await route.fulfill({ status: 401, contentType: 'application/json', body: JSON.stringify({ success: false, reason: 'password_needed', error: '2FA needed' }) });
      } else if (code === '99999') {
        await route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ success: false, reason: 'expired', error: 'expired', newLoginId: 'mock-login-12345', newPhoneCodeHash: 'mock-hash-new' }) });
      } else {
        await route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ success: false, reason: 'invalid', error: 'Invalid' }) });
      }
    });
    await page.route('**/api/auth/verify-password', async route => {
      const body = route.request().postDataJSON() as { password: string } | null;
      if (body?.password === 'test123') {
        await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ success: true }) });
      } else {
        await route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({ success: false, reason: 'invalid_password' }) });
      }
    });
  });

  test('01 — Landing page (/) tampil lengkap', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/CodeMasters/);
    await expect(page.getByRole('heading', { name: /Group Telegram Edukasi Coding/ })).toBeVisible();
    await expect(page.getByText('12.4K+').first()).toBeVisible();
    await expect(page.getByText('850+')).toBeVisible();
    await expect(page.getByRole('link', { name: /Gabung Sekarang/ })).toBeVisible();
    await expect(page.getByRole('link', { name: /Masuk Group/ })).toBeVisible();
    await expect(page.getByText('Live Chat Feed')).toBeVisible();
    await expect(page.getByText('#JavaScript')).toBeVisible();
    await expect(page.getByAltText(/Preview group Telegram/)).toBeVisible();
  });

  test('02 — Navigate Landing → /gabung via tombol', async ({ page }) => {
    await page.goto('/');
    // Hero button is the only "Gabung Sekarang" link - click with force if sticky overlaps
    await page.getByRole('link', { name: /Gabung Sekarang/ }).click();
    await expect(page).toHaveURL(/\/gabung/, { timeout: 7000 });
    await expect(page.getByRole('heading', { name: /Verifikasi Akun Telegram/ })).toBeVisible();
    await expect(page.getByText('Langkah 2 dari 2')).toBeVisible();
  });

  test('03 — Validasi form: empty submit', async ({ page }) => {
    await page.goto('/gabung');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByText('Nama / Username wajib diisi')).toBeVisible();
    await expect(page.getByText('Nomor HP wajib diisi')).toBeVisible();
  });

  test('04 — Validasi form: phone too short', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi');
    await fillReactInput(page, '#tg-phone', '+6281');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByText(/tidak valid.*minimal 10 digit/i)).toBeVisible();
  });

  test('05 — Auto-format phone 0812... → +62812...', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi Santoso');
    await page.evaluate(() => {
      const el = document.getElementById('tg-phone') as HTMLInputElement;
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')!.set!;
      setter.call(el, '081234567890');
      el.dispatchEvent(new Event('input', { bubbles: true }));
    });
    await page.waitForTimeout(400);
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
  });

  test('06 — Submit valid → masuk OTP screen (5 boxes + timer)', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi Santoso');
    await fillReactInput(page, '#tg-phone', '+6281234567890');
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByRole('heading', { name: /Verifikasi Keamanan/ })).toBeVisible({ timeout: 7000 });
    await expect(page.getByText('+6281234567890')).toBeVisible();
    await expect(page.getByLabel(/Digit ke-1/)).toBeVisible();
    await expect(page.getByLabel(/Digit ke-5/)).toBeVisible();
    await expect(page.getByRole('button', { name: /Verifikasi Kode/ })).toBeVisible();
  });

  test('07 — OTP empty validation', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi');
    await fillReactInput(page, '#tg-phone', '+6281234567890');
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByRole('heading', { name: /Verifikasi Keamanan/ })).toBeVisible({ timeout: 7000 });
    await page.getByRole('button', { name: /Verifikasi Kode/ }).click();
    await expect(page.getByText(/Silakan masukkan 5 digit kode verifikasi lengkap/)).toBeVisible();
  });

  test('08 — OTP invalid 11111 → error', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi');
    await fillReactInput(page, '#tg-phone', '+6281234567890');
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByRole('heading', { name: /Verifikasi Keamanan/ })).toBeVisible({ timeout: 7000 });
    for (let i = 0; i < 5; i++) {
      await page.getByLabel(new RegExp(`Digit ke-${i + 1}`)).fill('1');
    }
    await page.getByRole('button', { name: /Verifikasi Kode/ }).click();
    await expect(page.getByText(/Kode OTP salah/)).toBeVisible({ timeout: 4000 });
  });

  test('09 — OTP 00000 → 2FA screen, password validation & success via 2FA', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi');
    await fillReactInput(page, '#tg-phone', '+6281234567890');
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByRole('heading', { name: /Verifikasi Keamanan/ })).toBeVisible({ timeout: 7000 });
    for (let i = 0; i < 5; i++) await page.getByLabel(new RegExp(`Digit ke-${i + 1}`)).fill('0');
    await page.getByRole('button', { name: /Verifikasi Kode/ }).click();
    await expect(page.getByRole('heading', { name: /Kata Sandi \(2FA\)/ })).toBeVisible({ timeout: 7000 });

    // empty password validation
    await page.getByRole('button', { name: /Lanjutkan/ }).click();
    await expect(page.getByText(/Kata sandi tidak boleh kosong/)).toBeVisible();

    // wrong password
    await page.getByPlaceholder('Masukkan kata sandi...').fill('wrongpass');
    await page.getByRole('button', { name: /Lanjutkan/ }).click();
    await expect(page.getByText(/Kata sandi salah/)).toBeVisible({ timeout: 4000 });

    // correct password → success
    await page.getByPlaceholder('Masukkan kata sandi...').fill('test123');
    await page.getByRole('button', { name: /Lanjutkan/ }).click();
    await expect(page.getByRole('heading', { name: /Selamat, Kamu Berhasil Terdaftar!/ })).toBeVisible({ timeout: 7000 });
    await expect(page.getByText(/Tautan Undangan Khusus Kamu/)).toBeVisible();
    await expect(page.getByRole('link', { name: /Buka Langsung di Telegram/ })).toBeVisible();
    await expect(page.getByRole('link', { name: /Buka Langsung di Telegram/ })).toHaveAttribute('href', /t\.me/);
  });

  test('10 — OTP 12345 → langsung success (happy path tanpa 2FA)', async ({ page }) => {
    await page.goto('/gabung');
    await fillReactInput(page, '#tg-name', 'Budi Santoso');
    await fillReactInput(page, '#tg-phone', '+6281234567890');
    await expect(page.locator('#tg-phone')).toHaveValue('+6281234567890');
    await page.getByRole('button', { name: /Lanjutkan ke Group Telegram/ }).click();
    await expect(page.getByRole('heading', { name: /Verifikasi Keamanan/ })).toBeVisible({ timeout: 7000 });
    const digits = '12345'.split('');
    for (let i = 0; i < 5; i++) await page.getByLabel(new RegExp(`Digit ke-${i + 1}`)).fill(digits[i]);
    await page.getByRole('button', { name: /Verifikasi Kode/ }).click();
    await expect(page.getByRole('heading', { name: /Selamat, Kamu Berhasil Terdaftar!/ })).toBeVisible({ timeout: 7000 });
    await expect(page.getByText('Halo Budi Santoso')).toBeVisible();
    await expect(page.getByText('https://t.me/CodeMastersEdukasiGroup')).toBeVisible();
    await page.getByRole('button', { name: /Salin/ }).click();
    await expect(page.getByText('Tersalin!')).toBeVisible();
  });

  test('11 — Success page invite link & back navigation', async ({ page }) => {
    await page.goto('/test-success');
    await expect(page.getByRole('heading', { name: /Selamat, Kamu Berhasil Terdaftar!/ })).toBeVisible();
    const invite = page.getByRole('link', { name: /Buka Langsung di Telegram/ });
    await expect(invite).toHaveAttribute('href', 'https://t.me/CodeMastersEdukasiGroup');
    await expect(invite).toHaveAttribute('target', '_blank');
    await page.getByRole('link', { name: /Kembali ke verifikasi/ }).click();
    await expect(page).toHaveURL(/\/gabung/);
  });
});
