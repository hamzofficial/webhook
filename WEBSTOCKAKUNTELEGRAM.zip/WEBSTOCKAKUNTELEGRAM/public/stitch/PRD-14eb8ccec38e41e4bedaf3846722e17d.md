# Project Brief & PRD: Landing Page Komunitas Belajar Coding Telegram

## 1. Overview & Project Objective
- **Nama Proyek:** Landing Page Group Telegram Edukasi Coding ("CodeMasters Indonesia")
- **Tujuan Utama:** Mengonversi calon pelajar dan programmer pemula agar bergabung ke grup Telegram komunitas edukasi coding gratis.
- **Target Audiens:** Mahasiswa, pelajar, *career switchers*, dan developer pemula (level nol hingga junior) yang membutuhkan bimbingan langsung, mentor, dan teman belajar coding.
- **Format Target:** Mobile-First Responsive Web (dioptimalkan untuk pengguna smartphone).

---

## 2. Core Value Proposition & Message
- **Tagline:** *"Belajar coding dari nol bersama ribuan programmer dan mentor berpengalaman setiap hari."*
- **Nilai Tambah (Key Value):**
  - **Akses Gratis 100%:** Tanpa biaya pendaftaran atau langganan awal.
  - **Dukungan Komunitas 24/7:** Diskusi error/bug, solusi async/await, loops, list comprehension, dll.
  - **Bimbingan Terstruktur:** Panduan bertahap dari pemula (*scratch*) hingga tingkat mahir (*industry-ready*).
  - **Peer-to-Peer & Mentor Feedback:** Interaksi hangat mentor & mentee layaknya ruang diskusi santai di Telegram.

---

## 3. Visual Identity & Design System Specs
- **Inspirasi Visual:** Telegram App UI (Clean, Focused, Modern Light Theme).
- **Warna Utama:**
  - *Telegram Blue / Accent:* `#229ED9` / `#0088CC`
  - *Deep Navy / Text:* `#18222D` / `#222E3A`
  - *Background:* Soft Sky Slate `#F5F7FB` & Pure White `#FFFFFF`
  - *Accent Success:* `#2ECC71` (Indikator Online & Verified)
  - *Code & Tag Highlights:* `#E8F4FB`, `#F0F4F8`
- **Tipografi:** Plus Jakarta Sans & Inter (UI/Clean sans-serif) + JetBrains Mono (Code Snippets).
- **Tone of Voice:** Komunikatif, bersahabat, terpercaya, dan memotivasi (*encouraging*).

---

## 4. Key Page Sections & Architecture

### A. Hero Section & Social Proof
- **Badge Komunitas:** *Komunitas Belajar Coding Indonesia* dengan ikon Telegram.
- **Heading Utama:** *"Group Telegram Edukasi Coding"*.
- **Sub-headline Ringkas:** Ringkasan misi belajar coding gratis dari nol.
- **Social Proof Counter (Pills):**
  - `12.4K+` Member Aktif
  - `850+` Online Sekarang
  - `100%` Gratis Belajar
- **Primary CTA:** Tombol interaktif *"Gabung Sekarang"* dengan ikon pesawat kertas Telegram.
- **Trust Indicators:** Jaminan *"Gratis Masuk Group • Akses Diskusi 24/7"*.

### B. Visual Chat Proof (Interactive Mobile Mockup)
- **High-Fidelity Frame Smartphone:** Menampilkan preview asli dinamika chat Telegram.
- **Konten Mockup:**
  - Pinned Message: *Tip Hari Ini (Async/Await JavaScript)*.
  - Chat diskusi interaktif (tanya-jawab Python, solusi list comprehension dari mentor Lina).
  - Code review snippet JavaScript function `fetchData()`.
  - Reaksi emotikon hangat (🔥, 👍, 🚀).

### C. Live Activity Feed & Interactive Snippets
- Komponen live feed diskusi terkini untuk membuktikan grup aktif secara *real-time*.
- Tag topik populer yang dibahas: `#JavaScript`, `#Python`, `#ReactJS`, `#Golang`, `#Fullstack`, `#BugFixing`.

### D. Benefit & Learning Pathway (Roadmap)
1. **Kurikulum Step-by-Step:** Mulai dari fondasi web (HTML/CSS/JS) hingga backend & cloud.
2. **Review Kode Bersama Mentor:** Tangkapan layar kode dibantu perbaiki secara langsung.
3. **Sharing Info Loker & Magang:** Update info industri dan relasi sesama developer.

### E. Sticky Mobile Bottom Bar
- Mini bar mengambang di bawah layar: Ringkasan member online dan tombol *"Masuk Group"* agar konversi tetap tinggi saat scrolling.

---

## 5. Technical Requirements & Milestones
- **Platform:** Lightweight Static HTML5 + Tailwind CSS (Fast Loading < 1.5s di koneksi mobile).
- **Direct Link Target:** Deep-link langsung ke Telegram client (`tg://resolve?domain=...`) dengan fallback web URL (`https://t.me/...`).
- **Analytics & Tracking:** Tracking klik tombol CTA (Event: `Click_Join_Telegram_Hero` & `Click_Join_Telegram_Sticky`).
- **SEO Meta:** OpenGraph tags & Twitter Card dengan preview mockup gambar Telegram agar menarik saat dibagikan di media sosial.
