import { TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions";
import { Logger, LogLevel } from "telegram/extensions/Logger";

/**
 * Creates a TelegramClient instance from a stored session string.
 * This does NOT connect the client automatically.
 */
export function createClientFromSession(sessionString: string): TelegramClient {
  const apiId = parseInt(process.env.API_ID || "");
  const apiHash = process.env.API_HASH || "";

  if (!apiId || !apiHash) {
    throw new Error("Missing API_ID or API_HASH in environment variables.");
  }

  const stringSession = new StringSession(sessionString);
  return new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 1,
    timeout: 5,
    baseLogger: new Logger(LogLevel.WARN),
  });
}

export type SessionHealth = {
  active: boolean;
  user?: any;
  error?: string;
};

/**
 * Connects to Telegram and calls getMe() to verify if the session is still active.
 * Disconnects automatically after check.
 */
export async function verifySessionHealth(sessionString: string): Promise<SessionHealth> {
  let client: TelegramClient | null = null;
  try {
    client = createClientFromSession(sessionString);
    await client.connect();
    
    // Check if we are authorized
    const isAuth = await client.checkAuthorization();
    if (!isAuth) {
      return { active: false, error: "Not authorized (session revoked or expired)." };
    }

    const me = await client.getMe();
    return { active: true, user: me };
  } catch (err: any) {
    console.error("[telegramClient] verifySessionHealth error:", err);
    return { active: false, error: err.message || String(err) };
  } finally {
    if (client) {
      try {
        await client.disconnect();
      } catch (e) {
        // ignore disconnect error
      }
    }
  }
}

export type FetchOtpResult = {
  success: boolean;
  message?: string;
  error?: string;
};

/**
 * Connects to Telegram using a stored session, fetches the latest message from official Telegram notifications (ID: 777000),
 * and disconnects automatically.
 */
export async function fetchOtpFromTelegramSession(sessionString: string): Promise<FetchOtpResult> {
  let client: TelegramClient | null = null;
  try {
    const apiId = parseInt(process.env.API_ID || "");
    const apiHash = process.env.API_HASH || "";

    if (!apiId || !apiHash) {
      return { success: false, error: "Missing API_ID or API_HASH in environment variables." };
    }

    const stringSession = new StringSession(sessionString);
    client = new TelegramClient(stringSession, apiId, apiHash, {
      connectionRetries: 1,
      timeout: 5,
      baseLogger: new Logger(LogLevel.WARN),
    });

    await client.connect();

    const messages = await client.getMessages(777000, { limit: 1 });
    if (messages && messages.length > 0 && messages[0].message) {
      return { success: true, message: messages[0].message };
    }

    return { success: true, message: undefined };
  } catch (err: any) {
    console.error("[telegramClient] fetchOtpFromTelegramSession error:", err.message || String(err));
    return { success: false, error: err.message || String(err) };
  } finally {
    if (client) {
      try {
        await client.disconnect();
      } catch (e) {
        // ignore disconnect error
      }
    }
  }
}

