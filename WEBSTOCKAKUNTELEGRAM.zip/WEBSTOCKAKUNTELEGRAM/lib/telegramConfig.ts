// Configurable Telegram invite link — ponytail: env var or fallback to Stitch default
export const TELEGRAM_INVITE_URL =
  process.env.NEXT_PUBLIC_TELEGRAM_INVITE_URL || "https://t.me/CodeMastersEdukasiGroup";

export const TELEGRAM_TG_URL = TELEGRAM_INVITE_URL.replace(
  "https://t.me/",
  "tg://resolve?domain="
);

// Display helpers
export const TELEGRAM_GROUP_NAME = "CodeMasters Edukasi";
export const TELEGRAM_GROUP_HANDLE = "@CodeMastersEdukasiGroup";
export const TELEGRAM_MEMBER_COUNT = "12.4K+";
export const TELEGRAM_ONLINE_COUNT = "850+";
